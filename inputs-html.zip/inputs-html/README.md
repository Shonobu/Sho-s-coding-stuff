# Inputs.html

A Pen created on CodePen.io. Original URL: [https://codepen.io/Shonobu/pen/wvXYXZo](https://codepen.io/Shonobu/pen/wvXYXZo).

